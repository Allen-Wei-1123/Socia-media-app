import * as firebase from 'firebase'


  var firebaseConfig = {
      apiKey: "AIzaSyCCZxxKqQZTumgOGTT2CTKk5emaJOJkN1Q",
      authDomain: "social-media-adea7.firebaseapp.com",
      databaseURL: "https://social-media-adea7.firebaseio.com",
      projectId: "social-media-adea7",
      storageBucket: "social-media-adea7.appspot.com",
      messagingSenderId: "387483246875",
      appId: "1:387483246875:web:9469bc16a7be4bad1273be",
      measurementId: "G-9WLRNZ4J22"
    };
  
    export default firebase.initializeApp(firebaseConfig)